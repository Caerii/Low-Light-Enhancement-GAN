% 2D/Demo MCALab sub-directory, Version 110
%
% The routines in this directory contain some code to demonstrate 2D MCA and 
% Inpaiting capabilities.
%
% 	 GUI Demo: Datasets must loaded in the workspace and then browsed.
%
% LoadSignal.*		-	Signal load browser GUI.
% MCAGUI.*		-	MCA GUI.
% MCA1Demo.m		-	Routine to be called to launch the MCA GUI.
%


