The main entry is RecoverCSS_singlePic.m.

CCDC_meas.mat: the measured reflectance of CCDC
cmfCanon60D.mat: the measured camera spectral sensitivity of Canon 60D used as ground truth
daylightScalars.txt: the scalars for daylight spectra

dict:
camSpecSensitivity: the camera spectral sensitivity of cameras
raw: an example captured by Canon 60D (CR2)


In the './raw/' folder, 
canon60d_black.pgm: the captured image w/ lens cap on
daylight.mat: measured daylight used as ground truth
img_0153.cr2: the captured image
xycorner.mat: the coordinates of the four corners of CCDC in the captured image